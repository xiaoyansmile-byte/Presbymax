// 统一菜单配置
const menuConfig = {
  items: [
    { id: 'home', label: '首页', url: 'index.html' },
    { id: 'admin', label: '管理后台', url: 'admin.html' },
    { id: 'auth', label: '用户管理', url: 'auth.html' },
    { id: 'analytics', label: '数据分析', url: 'analytics.html' },
    { id: 'plans', label: '训练计划', url: 'plans.html' },
    { id: 'execute', label: '执行计划', url: 'execute-plan.html' },
    { id: 'reminders', label: '提醒设置', url: 'reminders.html' },
    { id: 'reports', label: '训练报告', url: 'reports.html' },
    { id: 'sync', label: '数据同步', url: 'sync.html' }
  ]
};

// 生成菜单HTML
function generateMenu() {
  const menuItems = menuConfig.items.map(item => 
    `<a href="${item.url}" class="menu-item">${item.label}</a>`
  ).join('');
  
  return `
    <div class="menu-container">
      <button class="menu-button">菜单 ▼</button>
      <div class="menu-dropdown">
        ${menuItems}
      </div>
    </div>
  `;
}

// 加载菜单到页面
function loadMenu() {
  const menuContainer = document.getElementById('menu-container');
  if (menuContainer) {
    menuContainer.innerHTML = generateMenu();
  }
}

// 当DOM加载完成后加载菜单
document.addEventListener('DOMContentLoaded', loadMenu);
